// Minimal runtime for Teams tab install buttons
document.querySelectorAll('#installButton, #installButton2').forEach(btn => {
  btn.addEventListener('click', () => {
    alert('To install in Teams: Apps → Manage your apps → Upload a custom app → select the ZIP I provided.');
  });
});
