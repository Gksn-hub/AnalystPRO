/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */
import { GoogleGenAI, LiveServerMessage, Modality, Blob, Part } from '@google/genai';

// --- DOM ELEMENT REFERENCES ---
const startStopBtn = document.getElementById('start-stop-btn') as HTMLButtonElement;
const captureStepBtn = document.getElementById('capture-step-btn') as HTMLButtonElement;
const generateReportBtn = document.getElementById('generate-report-btn') as HTMLButtonElement;
const videoElement = document.getElementById('screen-preview') as HTMLVideoElement;
const placeholder = document.getElementById('placeholder') as HTMLDivElement;
const transcriptContainer = document.getElementById('transcript-container') as HTMLDivElement;
const stepsContainer = document.getElementById('steps-container') as HTMLDivElement;
const reportContainer = document.getElementById('report-container') as HTMLDivElement;

// --- STATE MANAGEMENT ---
let isRecording = false;
let mediaRecorder: MediaStream | null = null;
let screenStream: MediaStream | null = null;
let sessionPromise: Promise<any> | null = null;
let capturedSteps: { image: string, transcript: string, mimeType: string }[] = [];
let currentTranscript = '';

// Initialize the GoogleGenAI client
const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

// --- UTILITY FUNCTIONS for AUDIO & BASE64 ---
function encode(bytes: Uint8Array): string {
  let binary = '';
  const len = bytes.byteLength;
  for (let i = 0; i < len; i++) {
    binary += String.fromCharCode(bytes[i]);
  }
  return btoa(binary);
}

function createBlob(data: Float32Array): Blob {
  const l = data.length;
  const int16 = new Int16Array(l);
  for (let i = 0; i < l; i++) {
    int16[i] = data[i] * 32768;
  }
  return {
    data: encode(new Uint8Array(int16.buffer)),
    mimeType: 'audio/pcm;rate=16000',
  };
}

const blobToBase64 = (blob: Blob): Promise<string> => {
    return new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.onloadend = () => resolve((reader.result as string).split(',')[1]);
        reader.onerror = reject;
        reader.readAsDataURL(blob);
    });
};


// --- CORE APPLICATION LOGIC ---

/**
 * Handles starting and stopping the recording session.
 */
async function handleStartStop() {
    if (isRecording) {
        // --- STOP RECORDING ---
        if (screenStream) {
            screenStream.getTracks().forEach(track => track.stop());
            screenStream = null;
        }
        if (mediaRecorder) {
            mediaRecorder.getTracks().forEach(track => track.stop());
            mediaRecorder = null;
        }
        if (sessionPromise) {
            const session = await sessionPromise;
            session.close();
            sessionPromise = null;
        }

        videoElement.srcObject = null;
        videoElement.classList.add('hidden');
        placeholder.classList.remove('hidden');

        startStopBtn.textContent = 'Start Recording';
        startStopBtn.classList.remove('danger');
        captureStepBtn.classList.add('hidden');
        if (capturedSteps.length > 0) {
            generateReportBtn.classList.remove('hidden');
        }
        isRecording = false;
    } else {
        // --- START RECORDING ---
        try {
            // Reset state
            capturedSteps = [];
            currentTranscript = '';
            updateStepsUI();
            reportContainer.innerHTML = '<p class="placeholder-text">Your generated report will appear here.</p>';

            // Get streams
            screenStream = await navigator.mediaDevices.getDisplayMedia({
                video: true,
                audio: false, // We'll capture audio separately for better control
            });
            mediaRecorder = await navigator.mediaDevices.getUserMedia({ audio: true });

            videoElement.srcObject = screenStream;
            videoElement.classList.remove('hidden');
            placeholder.classList.add('hidden');

            // Handle user stopping screen share from browser UI
            screenStream.getVideoTracks()[0].onended = () => {
                if (isRecording) handleStartStop();
            };

            // Connect to Gemini Live API
            await connectToLive();

            startStopBtn.textContent = 'Stop Recording';
            startStopBtn.classList.add('danger');
            captureStepBtn.classList.remove('hidden');
            generateReportBtn.classList.add('hidden');
            isRecording = true;

        } catch (error) {
            console.error("Failed to start recording:", error);
            alert("Could not start recording. Please ensure you have given the necessary permissions and try again.");
        }
    }
}

/**
 * Establishes a connection to the Gemini Live API for real-time transcription.
 */
async function connectToLive() {
    // Fix: Cast window to `any` to support vendor-prefixed `webkitAudioContext` without causing a TypeScript error.
    const inputAudioContext = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 16000 });

    sessionPromise = ai.live.connect({
        model: 'gemini-2.5-flash-native-audio-preview-09-2025',
        callbacks: {
            onopen: () => {
                console.log('Live session opened.');
                if (!mediaRecorder) return;
                const source = inputAudioContext.createMediaStreamSource(mediaRecorder);
                const scriptProcessor = inputAudioContext.createScriptProcessor(4096, 1, 1);
                
                scriptProcessor.onaudioprocess = (audioProcessingEvent) => {
                    const inputData = audioProcessingEvent.inputBuffer.getChannelData(0);
                    const pcmBlob = createBlob(inputData);
                    sessionPromise?.then((session) => {
                        session.sendRealtimeInput({ media: pcmBlob });
                    });
                };
                
                source.connect(scriptProcessor);
                scriptProcessor.connect(inputAudioContext.destination);
            },
            onmessage: (message: LiveServerMessage) => {
                if (message.serverContent?.inputTranscription) {
                    const text = message.serverContent.inputTranscription.text;
                    currentTranscript += text;
                    transcriptContainer.textContent = currentTranscript;
                }
                 if (message.serverContent?.turnComplete) {
                    console.log('Turn complete.');
                }
            },
            onerror: (e: ErrorEvent) => console.error('Live session error:', e),
            onclose: (e: CloseEvent) => console.log('Live session closed.'),
        },
        config: {
            responseModalities: [Modality.AUDIO],
            inputAudioTranscription: {},
        },
    });
}


/**
 * Captures a single step (screenshot and transcript).
 */
function handleCaptureStep() {
    if (!screenStream || !videoElement) return;

    const canvas = document.createElement('canvas');
    canvas.width = videoElement.videoWidth;
    canvas.height = videoElement.videoHeight;
    const context = canvas.getContext('2d');
    if (context) {
        context.drawImage(videoElement, 0, 0, canvas.width, canvas.height);
        const mimeType = 'image/jpeg';
        const dataUrl = canvas.toDataURL(mimeType, 0.9);
        const base64Image = dataUrl.split(',')[1];
        
        capturedSteps.push({
            image: base64Image,
            mimeType,
            transcript: currentTranscript.trim() || "No commentary provided for this step."
        });

        // Reset transcript for the next step
        currentTranscript = '';
        transcriptContainer.textContent = '';
        updateStepsUI();
    }
}

/**
 * Renders the list of captured steps in the UI.
 */
function updateStepsUI() {
    if (capturedSteps.length === 0) {
        stepsContainer.innerHTML = '<p class="placeholder-text">Captured steps will be displayed here.</p>';
        return;
    }
    
    stepsContainer.innerHTML = ''; // Clear previous steps
    capturedSteps.forEach((step, index) => {
        const stepElement = document.createElement('div');
        stepElement.className = 'step-item';
        stepElement.innerHTML = `
            <div class="step-header">Step ${index + 1}</div>
            <img src="data:${step.mimeType};base64,${step.image}" alt="Screenshot for step ${index + 1}">
            <p>${step.transcript}</p>
        `;
        stepsContainer.appendChild(stepElement);
    });
}

/**
 * Generates the final RPA analysis report using the Gemini API.
 */
async function handleGenerateReport() {
    if (capturedSteps.length === 0) {
        alert("No steps captured. Please record a process first.");
        return;
    }

    generateReportBtn.disabled = true;
    generateReportBtn.textContent = 'Generating...';
    reportContainer.innerHTML = '';

    const systemInstruction = `You are AnalystPRO, an expert AI process analyst. 
    Your task is to create a detailed process design document (PDD) based on the following user steps. 
    Each step includes a screenshot and a spoken description from the user. 
    Analyze the image and the text to describe the user's action, the UI elements involved, and any important context. 
    Format the output as a clean and professional Markdown document. 
    Include a title, a brief summary of the process, and then a numbered list of the detailed steps.`;

    const contents: Part[] = capturedSteps.flatMap((step, index) => [
        { text: `\n\n---\n\n## Step ${index + 1}: User Commentary\n\n${step.transcript}` },
        {
            inlineData: {
                mimeType: step.mimeType,
                data: step.image
            }
        }
    ]);
    
    try {
        const responseStream = await ai.models.generateContentStream({
            model: 'gemini-2.5-flash',
            contents: [{role: 'user', parts: contents}],
            config: {
                systemInstruction: systemInstruction,
            }
        });

        let firstChunk = true;
        for await (const chunk of responseStream) {
            if (firstChunk) {
                reportContainer.innerHTML = ''; // Clear placeholder
                firstChunk = false;
            }
            // This is a simplistic way to render markdown; a library could be used for more complex cases.
            reportContainer.innerHTML += chunk.text.replace(/\n/g, '<br>');
        }

    } catch (error) {
        console.error("Error generating report:", error);
        reportContainer.textContent = "An error occurred while generating the report. Please check the console.";
    } finally {
        generateReportBtn.disabled = false;
        generateReportBtn.textContent = 'Generate Analysis';
    }
}


// --- EVENT LISTENERS ---
startStopBtn.addEventListener('click', handleStartStop);
captureStepBtn.addEventListener('click', handleCaptureStep);
generateReportBtn.addEventListener('click', handleGenerateReport);
window.addEventListener('load', () => {
    videoElement.classList.add('hidden');
});